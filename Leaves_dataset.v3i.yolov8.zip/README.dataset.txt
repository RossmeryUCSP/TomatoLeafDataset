# Leaves_dataset > 2023-07-14 2:17am
https://universe.roboflow.com/tesis-eiflj/leaves_dataset

Provided by a Roboflow user
License: Public Domain

